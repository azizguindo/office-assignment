import React,{Component} from 'react'
import {
  Badge,
  Button,
  FormControl,
  Icon,
  Input,
  InputLabel, Menu, MenuItem,
  Snackbar,
  Table,
  TableBody,
  TableCell,
  TableHead, TableRow, Tooltip
} from "@material-ui/core";
import AddUser from "./AddUser";
import Service from "../service/Service";
import {
  URL_ST_ADD, URL_ST_ALL, URL_ST_UPDATE,
  URL_USER_ADD,
  URL_USER_ALL, URL_USER_DELETE,
  URL_USER_UPDATE
} from "../utils/Constant";

export default class ListUser extends Component {
  constructor(props) {
    super(props);
    this.state={
      lesUtilisateurs:[],
      isOpened:false,
      modeEdit:false,
      editValue:{}
    }
  }

  componentWillMount() {
    try {
      Service.get(URL_USER_ALL)
      .then(data=>{
        this.setState({lesUtilisateurs:data});
      });

    }catch (e) {
      console.log("erreur",e.toString());
    }
  }

  handleDelete=(event)=>{
    const id=event.currentTarget.getAttribute("tag");
    const {lesUtilisateurs}=this.state;
    this.setState({lesUtilisateurs:lesUtilisateurs.filter(item=> item.id!=id) })
    Service.update(URL_USER_DELETE+"/"+id,{},"DELETE")
  }



  handleAdd=(event)=>{
    this.setState({isOpened:true})
  }
  dialogClose=()=>{
    this.setState({isOpened:false})
  }
  save=(p,modeEdit)=>
  {
    const lesUtilisateurs=this.state.lesUtilisateurs
    Service.update(modeEdit==false?URL_USER_ADD:(URL_USER_UPDATE+"/"+p.id),p,modeEdit?"PUT":"POST")
    .then(data=>{
      if(modeEdit==false) {
        lesUtilisateurs.push(p);
      }else
      {
        const index=lesUtilisateurs.findIndex((user)=>{
          return user.numero==p.numero;
        });

        lesUtilisateurs[index]=p;

      }
      this.setState({modeEdit:false,lesUtilisateurs:lesUtilisateurs});
    })
  }
  handleEdit=(event)=>{
    const lesUtilisateurs =this.state.lesUtilisateurs;
    const id=event.currentTarget.getAttribute("tag");

    const u=lesUtilisateurs.find((user)=>{

      return user.id==id;
    });
    console.log(u);
    this.setState({
      modeEdit:true,
      isOpened:true,
      editValue:u
    })
  }

  render() {
    const {lesUtilisateurs,anchorEL}=this.state;
    return(
      <div>
        <div>
          <Button onClick={this.handleAdd}><Icon>add_circle</Icon></Button>
          <AddUser editMode={this.state.modeEdit} editValue={this.state.editValue}  opened={this.state.isOpened} closed={this.dialogClose} saved={this.save}></AddUser>
        </div>
        <Table >
          <TableHead style={{background:"beige"}}>
            <TableCell>Nom</TableCell>
            <TableCell>Prenom</TableCell>
            <TableCell>Statut</TableCell>
            <TableCell>Date d'arrivée</TableCell>
            <TableCell>Date de départ</TableCell>
            <TableCell>Bureau</TableCell>
            <TableCell></TableCell>
          </TableHead>
          <TableBody>
            {
              lesUtilisateurs.map((user)=>(
                <TableRow key={user.id}   >
                  <TableCell>{user.nom}</TableCell>
                  <TableCell>{user.prenom}</TableCell>
                  <TableCell>{user.statut.nom}</TableCell>
                  <TableCell>{user.dateArrivee}</TableCell>
                  <TableCell>{user.dateDepart}</TableCell>
                  <TableCell>00</TableCell>
                  <TableCell>
                    <Button  tag={user.id} onClick={this.handleDelete}   color={"primary"}><Icon>delete</Icon></Button>
                    <Button tag={user.id} onClick={this.handleEdit} color={"primary"}><Icon>edit</Icon></Button>
                  </TableCell>
                </TableRow>

              ))
            }
          </TableBody>
        </Table>
      </div>
    );
  }





}
