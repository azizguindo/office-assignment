
const URL="http://localhost:8080/api";

export const URL_BU_ADD=URL+"/offices";
export const URL_BU_ALL=URL+"/offices";
export const URL_BU_GET_ONE=URL+"/offices/";//+id
export const URL_BU_UPDATE=URL+"/offices/"//+id
export const URL_BU_DELETE=URL+"/offices/"//+id

export const URL_USER_ADD=URL+"/users";//post
export const URL_USER_ALL=URL+"/users";
export const URL_USER_GET_ONE=URL+"/users/";//+id
export const URL_USER_UPDATE=URL+"/user/"//+id
export const URL_USER_DELETE=URL+"/user/"//+id


export const URL_ST_ALL=URL+"/statuts/";
export const URL_ST_ADD=URL+"/statuts";//post
export const URL_ST_GET_ONE=URL+"/statuts/";//+id
export const URL_ST_UPDATE=URL+"/statuts/"//+id



export default URL;
